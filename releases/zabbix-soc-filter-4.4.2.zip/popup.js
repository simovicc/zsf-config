'use strict';

const browserAPI = (typeof browser !== 'undefined') ? browser :
                   (typeof chrome !== 'undefined') ? chrome : null;

const $ = function (id) { return document.getElementById(id); };

const statusEl = $('status');
const visibleEl = $('visible');
const countEl = $('count');
const filterZone = $('filter-zone');
const filterStateEl = $('filter-state');
const soundZone = $('sound-zone');
const volumeSlider = $('volume-slider');
const volumeValue = $('volume-value');
const notifZone = $('notif-zone');
const permWarn = $('perm-warn');
const dccptLinkBtn = $('dccpt-link-btn');
const analystNameInput = $('analyst-name');
const namePanel = $('name-panel');

const DCCPT_URL = 'https://comtradegroup.sharepoint.com/:x:/r/sites/ICT-Delivery657/_layouts/15/Doc2.aspx?action=edit&sourcedoc=%7Bcc7e1ee2-077d-46a2-a126-3afb92384a66%7D&wdOrigin=TEAMS-MAGLEV.undefined_ns.rwc&wdExp=TEAMS-TREATMENT&wdhostclicktime=1762686101302&web=1';

let state = {
  enabled: true,
  soundEnabled: true,
  soundVolume: 0.5,
  notificationsEnabled: true,
  notificationPermission: 'default',
  hiddenCount: 0,
  visibleCount: 0,
  analystName: '',
  isDonDon: false
};

let activeTabId = null;
let isReady = false;
let inFlight = false;

function setZoneState(zone, isOn, isDisabled) {
  if (!zone) return;
  zone.classList.toggle('is-on', !!isOn);
  zone.classList.toggle('is-disabled', !!isDisabled);
}

function updatePermWarn(permission) {
  while (permWarn.firstChild) permWarn.removeChild(permWarn.firstChild);
  if (!isReady || !state.notificationsEnabled || permission === 'granted' || permission === 'unsupported') {
    permWarn.classList.add('hidden');
    return;
  }
  permWarn.classList.remove('hidden');
  if (permission === 'denied') {
    permWarn.appendChild(document.createTextNode('Dozvola za notifikacije je odbijena. Otvori podešavanja sajta za Zabbix (ikona pored adrese) i ručno dozvoli notifikacije.'));
  } else {
    permWarn.appendChild(document.createTextNode('Notifikacije još nisu odobrene u browseru.'));
    const btn = document.createElement('button');
    btn.className = 'perm-warn-btn';
    btn.type = 'button';
    btn.textContent = 'Zatraži dozvolu';
    btn.addEventListener('click', requestNotifPermission);
    permWarn.appendChild(document.createElement('br'));
    permWarn.appendChild(btn);
  }
}

async function requestNotifPermission() {
  const resp = await send('requestNotificationPermission');
  if (resp && resp.permission) {
    state.notificationPermission = resp.permission;
    renderUI();
  }
}

function renderUI() {
  statusEl.textContent = !isReady ? 'N/A' : (state.enabled ? 'FOKUS AKTIVAN' : 'PUN PRIKAZ');
  statusEl.className = 'status-value ' + (!isReady ? 'off' : (state.enabled ? 'on' : 'off'));

  visibleEl.textContent = isReady ? state.visibleCount : '-';
  countEl.textContent = isReady ? state.hiddenCount : '-';

  setZoneState(filterZone, state.enabled, !isReady);
  filterStateEl.textContent = !isReady ? 'OTVORI ZABBIX' :
                              (state.enabled ? 'UKLJUČEN' : 'ISKLJUČEN');

  setZoneState(soundZone, state.soundEnabled, !isReady);
  const volPct = Math.round((state.soundVolume != null ? state.soundVolume : 0.5) * 100);
  volumeSlider.value = volPct;
  volumeValue.textContent = volPct + '%';
  volumeSlider.disabled = !isReady || !state.soundEnabled;

  setZoneState(notifZone, state.notificationsEnabled, !isReady);
  updatePermWarn(state.notificationPermission);

  if (analystNameInput && document.activeElement !== analystNameInput) {
    analystNameInput.value = state.analystName || '';
  }
  if (analystNameInput) analystNameInput.disabled = !isReady;
  if (namePanel) namePanel.style.display = (isReady && state.isDonDon) ? 'none' : '';
}

function showInactive() {
  isReady = false;
  state = {
    enabled: false,
    soundEnabled: false,
    soundVolume: 0.5,
    notificationsEnabled: false,
    notificationPermission: 'default',
    hiddenCount: 0,
    visibleCount: 0,
    analystName: '',
    isDonDon: false
  };
  renderUI();
}

async function getActiveTab() {
  if (!browserAPI || !browserAPI.tabs) return null;
  try {
    const tabs = await browserAPI.tabs.query({ active: true, currentWindow: true });
    return tabs && tabs[0] ? tabs[0] : null;
  } catch (e) {
    return null;
  }
}

function send(action, extra) {
  return new Promise(function (resolve) {
    if (activeTabId == null || !browserAPI || !browserAPI.tabs) {
      resolve(null);
      return;
    }
    const msg = Object.assign({}, extra || {}, { action: action });
    let settled = false;
    let timeoutId = null;
    const finish = function (resp) {
      if (settled) return;
      settled = true;
      if (timeoutId !== null) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
      resolve(resp || null);
    };
    timeoutId = setTimeout(function () { finish(null); }, 3000);
    try {
      const result = browserAPI.tabs.sendMessage(activeTabId, msg, finish);
      if (result && typeof result.then === 'function') {
        result.then(finish).catch(function () { finish(null); });
      }
    } catch (e) {
      finish(null);
    }
  });
}

function applyResponseToState(response) {
  if (!response || typeof response !== 'object') return false;
  state.enabled = !!response.enabled;
  state.soundEnabled = !!response.soundEnabled;
  state.soundVolume = response.soundVolume != null ? response.soundVolume : 0.5;
  state.notificationsEnabled = !!response.notificationsEnabled;
  state.notificationPermission = response.notificationPermission || 'default';
  state.hiddenCount = response.hiddenCount || 0;
  state.visibleCount = response.visibleCount || 0;
  state.analystName = typeof response.analystName === 'string' ? response.analystName : '';
  state.isDonDon = !!response.isDonDon;
  return true;
}

async function loadStatus() {
  const tab = await getActiveTab();
  if (!tab || !tab.id) {
    showInactive();
    return;
  }
  activeTabId = tab.id;

  const response = await send('getStatus');
  if (applyResponseToState(response)) {
    isReady = true;
    renderUI();
  } else {
    showInactive();
  }
}

async function toggleAction(stateKey, sendAction) {
  if (!isReady || inFlight) return;
  inFlight = true;
  const oldValue = state[stateKey];
  state[stateKey] = !oldValue;
  renderUI();
  try {
    const resp = await send(sendAction, { enabled: state[stateKey] });
    if (!resp || !resp.ok) {
      state[stateKey] = oldValue;
      renderUI();
    }
  } catch (e) {
    state[stateKey] = oldValue;
    renderUI();
  } finally {
    inFlight = false;
  }
}

filterZone.addEventListener('click', function (e) {
  e.preventDefault();
  toggleAction('enabled', 'setEnabled');
});

let nameSaveTimer = null;
function saveAnalystName() {
  if (!isReady || !analystNameInput) return;
  const value = analystNameInput.value.trim();
  state.analystName = value;
  send('setAnalystName', { name: value });
}
if (analystNameInput) {
  analystNameInput.addEventListener('input', function () {
    if (nameSaveTimer) clearTimeout(nameSaveTimer);
    nameSaveTimer = setTimeout(saveAnalystName, 400);
  });
  analystNameInput.addEventListener('blur', function () {
    if (nameSaveTimer) { clearTimeout(nameSaveTimer); nameSaveTimer = null; }
    saveAnalystName();
  });
}

soundZone.addEventListener('click', function (e) {
  e.preventDefault();
  toggleAction('soundEnabled', 'setSoundEnabled');
});

notifZone.addEventListener('click', async function (e) {
  e.preventDefault();
  if (!isReady || inFlight) return;
  inFlight = true;

  const oldValue = state.notificationsEnabled;
  const newValue = !oldValue;
  state.notificationsEnabled = newValue;
  renderUI();

  try {
    const resp = await send('setNotificationsEnabled', { enabled: newValue });
    if (!resp || !resp.ok) {
      state.notificationsEnabled = oldValue;
      renderUI();
      return;
    }
    if (newValue) {
      const permResp = await send('requestNotificationPermission');
      if (permResp && permResp.permission) {
        state.notificationPermission = permResp.permission;
        renderUI();
      }
    }
  } catch (e) {
    state.notificationsEnabled = oldValue;
    renderUI();
  } finally {
    inFlight = false;
  }
});

volumeSlider.addEventListener('input', function () {
  const pct = parseInt(volumeSlider.value, 10);
  if (!isNaN(pct)) volumeValue.textContent = pct + '%';
});

volumeSlider.addEventListener('change', async function () {
  if (!isReady) return;
  const pct = parseInt(volumeSlider.value, 10);
  if (isNaN(pct)) return;
  const vol = pct / 100;
  state.soundVolume = vol;
  await send('setSoundVolume', { volume: vol });
});

dccptLinkBtn.addEventListener('click', function (e) {
  e.preventDefault();

  const fallbackOpen = function () {
    try {
      const win = window.open(DCCPT_URL, '_blank');
      if (win) {
        try { window.close(); } catch (closeErr) {}
      }
    } catch (openErr) {}
  };

  if (!browserAPI || !browserAPI.tabs || !browserAPI.tabs.create) {
    fallbackOpen();
    return;
  }

  let result;
  try {
    result = browserAPI.tabs.create({ url: DCCPT_URL });
  } catch (createErr) {
    fallbackOpen();
    return;
  }

  if (result && typeof result.then === 'function') {
    result.then(function () {
      try { window.close(); } catch (closeErr) {}
    }).catch(function () {
      fallbackOpen();
    });
  } else {
    setTimeout(function () {
      try { window.close(); } catch (closeErr) {}
    }, 150);
  }
});

const actUsernameInput = $('act-username');
const actTokenInput = $('act-token');
const actSubmitBtn = $('act-submit');
const actErrorEl = $('act-error');
const lockedReasonEl = $('locked-reason');
const lockedCheckBtn = $('locked-check');
const lockedDeactBtn = $('locked-deact');
const authUserEl = $('auth-user');
const authLogoutLink = $('auth-logout');
const updateBannerEl = $('update-banner');
const updateVersionEl = $('update-version');
const activationSection = $('activation-section');
const lockedSection = $('locked-section');
const activeSection = $('active-section');

const contactEmailA = $('ct-email-a');
const contactEmailB = $('ct-email-b');
const contactLiA = $('ct-li-a');
const contactLiB = $('ct-li-b');
if (contactEmailA) contactEmailA.href = 'mailto:ssimovic@comtrade.com';
if (contactEmailB) contactEmailB.href = 'mailto:ssimovic@comtrade.com';
if (contactLiA) contactLiA.href = 'https://linkedin.com/in/simovicc';
if (contactLiB) contactLiB.href = 'https://linkedin.com/in/simovicc';

const locationBadge = $('location-badge');
const locationTextEl = $('location-text');
function setLocationBadge(label, detail, errorState) {
  if (!locationBadge || !locationTextEl) return;
  locationBadge.classList.remove('hidden');
  locationBadge.classList.remove('location-badge--office', 'location-badge--vpn', 'location-badge--home');

  let baseText = '';
  let cls = '';
  if (label === 'office') { baseText = 'CTSI SOC kancelarija'; cls = 'location-badge--office'; }
  else if (label === 'home') { baseText = 'Rad od kuće'; cls = 'location-badge--home'; }
  else if (label === 'unknown' && errorState === 'all_services_failed' && !detail) {
    baseText = 'Mreža/firewall blokira IP servis';
  }

  let text = baseText;
  if (detail) {
    const vpnPart = 'VPN [' + detail + ']';
    text = baseText ? (baseText + ' + ' + vpnPart) : vpnPart;
    if (!cls) cls = 'location-badge--vpn';
  }
  if (!text) text = 'Provera lokacije...';

  locationTextEl.textContent = text;
  if (cls) locationBadge.classList.add(cls);
}

function showSection(name) {
  if (activationSection) activationSection.hidden = name !== 'activation';
  if (lockedSection) lockedSection.hidden = name !== 'locked';
  if (activeSection) activeSection.hidden = name !== 'active';
}

function bgSend(payload) {
  return new Promise(function (resolve) {
    if (!browserAPI || !browserAPI.runtime) { resolve(null); return; }
    let settled = false;
    const finish = function (r) {
      if (settled) return;
      settled = true;
      resolve(r || null);
    };
    setTimeout(function () { finish(null); }, 12000);
    try {
      const result = browserAPI.runtime.sendMessage(payload, finish);
      if (result && typeof result.then === 'function') {
        result.then(finish).catch(function () { finish(null); });
      }
    } catch (e) { finish(null); }
  });
}

function describeLockReason(zsf) {
  if (zsf.versionState === 'locked') {
    if (zsf.versionReason === 'below_min') {
      return 'Tvoja verzija (' + zsf.myVersion + ') je ispod minimalne podržane (' + zsf.minVersion + '). Waterfox sam povlači update; Chrome korisnici skinu novi ZIP iz repo-a.';
    }
    if (zsf.versionReason === 'grace_expired_version') {
      return 'Update server nije dostupan više od 48h. Proveri internet pa klikni "Proveri sad".';
    }
  }
  if (zsf.authReason === 'revoked') return 'Pristup je opozvan. Kontaktiraj Stefana ako misliš da je greška.';
  if (zsf.authReason === 'not_found') return 'Korisnički nalog nije pronađen.';
  if (zsf.authReason === 'mismatch') return 'Token se ne poklapa sa serverskim.';
  if (zsf.authReason === 'grace_expired_auth') return 'Auth server nije dostupan više od 24 sata. Proveri internet pa klikni "Proveri sad".';
  return 'Razlog nije poznat.';
}

async function refreshAuthAndRender() {
  try { bgSend({ type: 'zsf.refreshLocation' }); } catch (e) {}
  const zsf = await bgSend({ type: 'zsf.getState' });
  if (!zsf) {
    setLocationBadge(null, null, null);
    showSection('active');
    await loadStatus();
    return;
  }
  setLocationBadge(zsf.locationLabel, zsf.locationDetail, zsf.locationError);
  if (zsf.state === 'pending') {
    showSection('activation');
  } else if (zsf.state === 'locked') {
    showSection('locked');
    if (lockedReasonEl) lockedReasonEl.textContent = describeLockReason(zsf);
  } else {
    showSection('active');
    if (authUserEl) authUserEl.textContent = zsf.username || '-';
    if (updateBannerEl && updateVersionEl) {
      if (zsf.versionState === 'update_available' && zsf.latestVersion) {
        updateBannerEl.classList.remove('hidden');
        updateVersionEl.textContent = zsf.latestVersion;
      } else {
        updateBannerEl.classList.add('hidden');
      }
    }
    await loadStatus();
  }
}

const actForm = $('act-form');

async function performActivation() {
  if (actErrorEl) actErrorEl.classList.add('hidden');
  if (actSubmitBtn) actSubmitBtn.disabled = true;
  const origText = actSubmitBtn ? actSubmitBtn.textContent : '';
  if (actSubmitBtn) actSubmitBtn.textContent = 'Proveravam...';
  const u = actUsernameInput ? actUsernameInput.value : '';
  const t = actTokenInput ? actTokenInput.value : '';
  const r = await bgSend({ type: 'zsf.activate', username: u, token: t });
  if (actSubmitBtn) {
    actSubmitBtn.disabled = false;
    actSubmitBtn.textContent = origText;
  }
  if (r && r.ok) {
    if (actUsernameInput) actUsernameInput.value = '';
    if (actTokenInput) actTokenInput.value = '';
    await refreshAuthAndRender();
  } else {
    if (actErrorEl) {
      actErrorEl.textContent = (r && r.error) || 'Greška pri aktivaciji.';
      actErrorEl.classList.remove('hidden');
    }
  }
}

if (actForm) {
  actForm.addEventListener('submit', function (e) {
    e.preventDefault();
    performActivation();
  });
}

if (actUsernameInput) {
  actUsernameInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && actTokenInput) {
      e.preventDefault();
      actTokenInput.focus();
    }
  });
}

let lockedCheckBusy = false;
if (lockedCheckBtn) {
  lockedCheckBtn.addEventListener('click', async function () {
    if (lockedCheckBusy) return;
    lockedCheckBusy = true;
    lockedCheckBtn.disabled = true;
    const orig = lockedCheckBtn.textContent;
    lockedCheckBtn.textContent = 'Proveravam...';
    await bgSend({ type: 'zsf.checkNow', what: 'both' });
    setTimeout(function () {
      lockedCheckBtn.disabled = false;
      lockedCheckBtn.textContent = orig;
      lockedCheckBusy = false;
      refreshAuthAndRender();
    }, 1200);
  });
}

const checkUpdateBtn = $('check-update-btn');
const updateCheckStatusEl = $('update-check-status');
let checkUpdateBusy = false;
if (checkUpdateBtn) {
  checkUpdateBtn.addEventListener('click', async function () {
    if (checkUpdateBusy) return;
    checkUpdateBusy = true;
    checkUpdateBtn.disabled = true;
    if (updateCheckStatusEl) {
      updateCheckStatusEl.className = 'update-check-status';
      updateCheckStatusEl.textContent = 'Proveravam...';
    }
    const res = await bgSend({ type: 'zsf.checkNow', what: 'version' });
    if (res && res.throttled) {
      if (updateCheckStatusEl) updateCheckStatusEl.textContent = 'Sačekaj malo pa probaj ponovo.';
      checkUpdateBtn.disabled = false;
      checkUpdateBusy = false;
      return;
    }
    setTimeout(async function () {
      const zsf = await bgSend({ type: 'zsf.getState' });
      if (updateCheckStatusEl && zsf) {
        const newer = zsf.latestVersion && zsf.myVersion && cmpVer(zsf.latestVersion, zsf.myVersion) > 0;
        if (newer) {
          updateCheckStatusEl.className = 'update-check-status new';
          updateCheckStatusEl.textContent = 'Nova verzija ' + zsf.latestVersion + ' dostupna';
          if (updateBannerEl && updateVersionEl) {
            updateBannerEl.classList.remove('hidden');
            updateVersionEl.textContent = zsf.latestVersion;
          }
        } else {
          updateCheckStatusEl.className = 'update-check-status ok';
          updateCheckStatusEl.textContent = 'Imaš najnoviju verziju (' + (zsf.myVersion || '') + ')';
        }
      } else if (updateCheckStatusEl) {
        updateCheckStatusEl.textContent = 'Greška pri proveri.';
      }
      checkUpdateBtn.disabled = false;
      checkUpdateBusy = false;
    }, 1200);
  });
}

function cmpVer(a, b) {
  const pa = String(a || '0').split('.').map(function (n) { return parseInt(n, 10) || 0; });
  const pb = String(b || '0').split('.').map(function (n) { return parseInt(n, 10) || 0; });
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

if (lockedDeactBtn) {
  lockedDeactBtn.addEventListener('click', async function () {
    await bgSend({ type: 'zsf.deactivate' });
    await refreshAuthAndRender();
  });
}

if (authLogoutLink) {
  authLogoutLink.addEventListener('click', async function (e) {
    e.preventDefault();
    await bgSend({ type: 'zsf.deactivate' });
    await refreshAuthAndRender();
  });
}

if (browserAPI && browserAPI.storage && browserAPI.storage.onChanged) {
  browserAPI.storage.onChanged.addListener(function (changes) {
    const keys = Object.keys(changes);
    if (keys.some(function (k) { return k.indexOf('zsf.') === 0; })) {
      refreshAuthAndRender();
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', refreshAuthAndRender);
} else {
  refreshAuthAndRender();
}
