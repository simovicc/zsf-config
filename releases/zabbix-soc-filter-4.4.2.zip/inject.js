(function () {
  'use strict';
  if (window.__socRefreshHook) return;
  window.__socRefreshHook = true;

  function isRefresh(s) {
    return typeof s === 'string' && s.indexOf('problem.view.refresh') !== -1;
  }

  function bodyMatch(body) {
    if (!body) return false;
    try {
      if (typeof body === 'string') return isRefresh(body);
      if (typeof URLSearchParams !== 'undefined' && body instanceof URLSearchParams) {
        return isRefresh(body.toString());
      }
    } catch (e) {}
    return false;
  }

  function fire(name) {
    try { document.dispatchEvent(new CustomEvent(name)); } catch (e) {}
  }

  const XHR = window.XMLHttpRequest;
  if (XHR && XHR.prototype) {
    const origOpen = XHR.prototype.open;
    const origSend = XHR.prototype.send;

    XHR.prototype.open = function (method, url) {
      try { this.__socUrl = url || ''; } catch (e) {}
      return origOpen.apply(this, arguments);
    };

    XHR.prototype.send = function (body) {
      let refresh = false;
      try { refresh = isRefresh(this.__socUrl) || bodyMatch(body); } catch (e) {}
      if (refresh) {
        fire('soc-refresh-start');
        try {
          this.addEventListener('loadend', function () { fire('soc-refresh-end'); });
        } catch (e) {}
      }
      return origSend.apply(this, arguments);
    };
  }

  const origFetch = window.fetch;
  if (origFetch) {
    window.fetch = function (input, init) {
      let url = '';
      try { url = (typeof input === 'string') ? input : (input && input.url) || ''; } catch (e) {}
      const refresh = isRefresh(url) || bodyMatch(init && init.body);
      if (refresh) fire('soc-refresh-start');
      const p = origFetch.apply(this, arguments);
      if (refresh && p && typeof p.then === 'function') {
        p.then(function () { fire('soc-refresh-end'); }, function () { fire('soc-refresh-end'); });
      }
      return p;
    };
  }
})();
